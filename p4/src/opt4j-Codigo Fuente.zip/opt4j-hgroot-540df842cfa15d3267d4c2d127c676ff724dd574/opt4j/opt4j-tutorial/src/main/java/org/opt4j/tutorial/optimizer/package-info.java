 

/**
 * The optimizer example shows the implementation of a simple optimizer which
 * uses the {@link org.opt4j.operators.mutate.Mutate} operator. The optimizer is
 * implemented in {@link org.opt4j.tutorial.optimizer.MutateOptimizer} and bound
 * using the {@link org.opt4j.tutorial.optimizer.MutateOptimizerModule}.
 */
package org.opt4j.tutorial.optimizer;

